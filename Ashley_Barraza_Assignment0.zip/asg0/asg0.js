function main() {
  const canvas = document.getElementById('cnv1');
  if (!canvas) {
    console.log('Failed to retrieve the <canvas> element');
    return;
  }

  const ctx = canvas.getContext('2d');

  ctx.fillStyle = 'rgba(0, 0, 0, 1.0)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Attach event listener to the draw button
  document.getElementById("drawButton").addEventListener("click", () => handleDrawEvent(ctx, canvas));
  document.getElementById("drawOperationButton").addEventListener("click", () => handleDrawOperationEvent(ctx, canvas));
}

function handleDrawEvent(ctx, canvas) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Fill the background with black
  ctx.fillStyle = 'rgba(0, 0, 0, 1.0)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Retrieve vector components
  v1_x = parseFloat(document.getElementById("v1_x").value);
  v1_y = parseFloat(document.getElementById("v1_y").value);
  v2_x = parseFloat(document.getElementById("v2_x").value);
  v2_y = parseFloat(document.getElementById("v2_y").value);

  // Create vectors
  v1 = new Vector3([v1_x, v1_y, 0]);
  v2 = new Vector3([v2_x, v2_y, 0]);

  // Draw the vectors
  drawVector(ctx, canvas, v1, "red");
  drawVector(ctx, canvas, v2, "blue");
}

function handleDrawOperationEvent(ctx, canvas) {
  // Clear the canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Fill the background with black
  ctx.fillStyle = 'rgba(0, 0, 0, 1.0)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Retrieve vector components
  v1_x = parseFloat(document.getElementById("v1_x").value);
  v1_y = parseFloat(document.getElementById("v1_y").value);
  v2_x = parseFloat(document.getElementById("v2_x").value);
  v2_y = parseFloat(document.getElementById("v2_y").value);

  const operation = document.getElementById("operation").value;
    const scalar = parseFloat(document.getElementById("scalar").value);

    v1 = new Vector3([v1_x, v1_y, 0]);
    v2 = new Vector3([v2_x, v2_y, 0]);

    drawVector(ctx, canvas, v1, "red");
    drawVector(ctx, canvas, v2, "blue");

    if (operation === "angle") {
        const { radians, degrees } = angleBetween(v1, v2);
        console.log(`Angle between v1 and v2: ${degrees.toFixed(2)}° (${radians.toFixed(2)} radians)`);
      
    } 
    else {
      if (operation === "add") {
        v3 = new Vector3(v1.elements).add(v2);
        drawVector(ctx, canvas, v3, "green");

      } 
      else if (operation === "sub") {
        v3 = new Vector3(v1.elements).sub(v2);
        drawVector(ctx, canvas, v3, "green");

      } 
      else if (operation === "mul") {
        v3 = new Vector3(v1.elements).mul(scalar);
        v4 = new Vector3(v2.elements).mul(scalar);
        drawVector(ctx, canvas, v3, "green");
        drawVector(ctx, canvas, v4, "green");

      } 
      else if (operation === "div") {
        v3 = new Vector3(v1.elements).div(scalar);
        v4 = new Vector3(v2.elements).div(scalar);
        drawVector(ctx, canvas, v3, "green");
        drawVector(ctx, canvas, v4, "green");
      }
      else if (operation === "mag") {
        console.log(`Magnitude of v1: ${v1.magnitude()}`);
        console.log(`Magnitude of v2: ${v2.magnitude()}`);

      } 
      else if (operation === "normal") {
    
          v1Norm = new Vector3(v1.elements).normalize();
          v2Norm = new Vector3(v2.elements).normalize();
          drawVector(ctx, canvas, v1Norm, "green");
          drawVector(ctx, canvas, v2Norm, "green");
      }
      else if(operation === "area") {
            area = areaTriangle(v1, v2);
            console.log(`Area of the triangle formed by v1 and v2: ${area.toFixed(2)}`);
      }
      
    }
    
}

function angleBetween(v1, v2) {
  dotProduct = Vector3.dot(v1, v2); // Use the static dot function
  magV1 = v1.magnitude();
  magV2 = v2.magnitude();

  if (magV1 === 0 || magV2 === 0) {
    throw new Error("Cannot calculate; lenghth is 0");
  }

  cosTheta = dotProduct / (magV1 * magV2);
  clampedCosTheta = Math.min(Math.max(cosTheta, -1), 1);
  Rad = Math.acos(clampedCosTheta);
  Deg = (Rad * 180) / Math.PI;

  return { radians: Rad, degrees: Deg };
}

function areaTriangle(v1, v2) {
  crossProduct = Vector3.cross(v1, v2); // Compute cross product
  mag = crossProduct.magnitude(); // Magnitude of the cross product
  return mag / 2; // Area of the triangle
}

function drawVector(ctx, canvas, v, color) {
  scale = 20; // Scale factor
  cx = canvas.width / 2; // Canvas center X
  cy = canvas.height / 2; // Canvas center Y

  // Draw the vector
  ctx.strokeStyle = color;
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx + v.elements[0] * scale, cy - v.elements[1] * scale);
  ctx.stroke();
}

